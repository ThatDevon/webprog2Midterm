export interface Sprite {
  url: string,
  x: number,
  y: number
}
