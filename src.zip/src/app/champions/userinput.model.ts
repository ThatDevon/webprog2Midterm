export interface UserInput {
  rating: number,
  comment: string,
  username: string,
  championName: string,
}
